# Operational & Payment Module
## Technical Documentation v1.0

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Business Module Overview](#2-business-module-overview)
3. [Payment System Architecture](#3-payment-system-architecture)
4. [Authentication & User Onboarding](#4-authentication--user-onboarding)
5. [Backend Reliability & Resilience](#5-backend-reliability--resilience)
6. [Data Privacy & Security](#6-data-privacy--security)
7. [Business Metrics & Analytics](#7-business-metrics--analytics)
8. [Appendices](#8-appendices)

---

## 1. Executive Summary

### 1.1 Purpose
This document provides comprehensive technical and operational specifications for the Operational & Payment Module, a multi-jurisdictional subscription and payment processing system designed to operate across the United Kingdom, Bangladesh, and India markets.

### 1.2 Scope
- Subscription lifecycle management
- Multi-tier pricing architecture
- Cross-border payment processing
- Regulatory compliance frameworks
- User authentication and onboarding flows
- System reliability and fault tolerance
- Data protection and privacy controls
- Business intelligence and metric tracking

### 1.3 Target Audience
- Software Engineers and Architects
- Product Managers
- Compliance Officers
- Security Engineers
- Business Intelligence Analysts
- Operations Teams

---

## 2. Business Module Overview

### 2.1 Subscription System Architecture

#### 2.1.1 Core Concepts

**Subscription Lifecycle States**
```
FREE → VALUE → PRO → UNLIMITED → ENTERPRISE
  ↓       ↓      ↓        ↓           ↓
ACTIVE / SUSPENDED / CANCELLED / EXPIRED
```

**State Definitions:**
- `ACTIVE`: Valid subscription with sufficient credits/payment
- `SUSPENDED`: Service blocked due to limit exceeded or payment failure
- `CANCELLED`: Subscription terminated by user
- `EXPIRED`: Subscription period ended without renewal

#### 2.1.2 Subscription Models

**Model Types:**
1. **Credit-Based System**: Monthly credit allocation with rollover options
2. **Hybrid Model**: Base subscription + credit consumption
3. **Freemium with Daily Bonuses**: Free tier with gamified engagement
4. **Overage Protection**: Enterprise feature for exceeding limits

**Credit System Architecture:**
- Credits serve as universal currency across all features
- Different features consume different credit amounts
- Credits refresh monthly based on subscription tier
- Additional credit packs available for purchase

### 2.2 Plan Tier Structure (Shothik AI)

#### 2.2.1 Tier Definitions

| Tier | Monthly Price (USD) | Monthly Credits | Agenting Solutions | Meta Marketing | Support Level |
|------|---------------------|-----------------|-------------------|----------------|---------------|
| **Free** | $0 | 520 (signup bonus + daily check-ins) | ❌ Not Included | ❌ Not Included | Community |
| **Value** | $19.99 | 2,000 + additional packs | ✅ Included | ❌ Not Included | Standard |
| **Pro** | $49.99 | 3,000 + 2,000 (Marketing) | ✅ Included | ✅ 1 Facebook Page | Priority |
| **Unlimited** | $99.99 | 6,000 + 6,000 (Marketing) | ✅ Included | ✅ 5 Facebook Pages | Priority |
| **Enterprise** | $450 | 12,000 (both pools) | ✅ Included | ✅ 35 Facebook Pages | Dedicated Manager |

#### 2.2.2 Currency Localization

**Multi-Currency Support:**
- **United Kingdom**: GBP (£) - Base rate: $1 = £0.79
- **Bangladesh**: BDT (৳) - Base rate: $1 = ৳109.50
- **India**: INR (₹) - Base rate: $1 = ₹83.20

**Dynamic Pricing Strategy:**
- Real-time exchange rate updates (daily)
- Purchase Power Parity (PPP) adjustments
- Regional promotional pricing
- Tiered discount structures (annual: 20%, quarterly: 10%)

### 2.3 Legal & Regulatory Compliance

#### 2.3.1 United Kingdom

**Regulatory Framework:**
- **GDPR Compliance**: Data Protection Act 2018
- **Payment Services**: FCA (Financial Conduct Authority) regulation
- **Consumer Rights**: Consumer Rights Act 2015
- **Tax Compliance**: VAT registration (20% standard rate)

**Key Requirements:**
- Right to erasure within 30 days
- Cookie consent mechanisms
- Clear cancellation terms (14-day cooling-off period)
- Transparent pricing display
- Secure payment processing (PCI DSS Level 1)

#### 2.3.2 Bangladesh

**Regulatory Framework:**
- **Data Protection**: Digital Security Act 2018
- **Payment Gateway**: Bangladesh Bank approval required
- **E-commerce**: E-commerce Guidelines 2019
- **Tax Compliance**: VAT (15%), Online Service Tax

**Key Requirements:**
- Local data residency options
- Bengali language support for T&C
- Mobile financial services integration (bKash, Nagad)
- Trade license verification
- Customer identity verification (KYC)

#### 2.3.3 India

**Regulatory Framework:**
- **Data Protection**: Digital Personal Data Protection Act 2023
- **Payment Systems**: RBI (Reserve Bank of India) regulations
- **Consumer Protection**: Consumer Protection Act 2019
- **Tax Compliance**: GST (18% standard rate)

**Key Requirements:**
- Data localization (critical personal data in India)
- Two-factor authentication mandatory
- UPI and RuPay integration
- Clear dispute resolution mechanism
- Automatic tax invoice generation

#### 2.3.4 Cross-Jurisdictional Compliance Matrix

| Requirement | UK | BD | India |
|-------------|----|----|-------|
| Data Residency | Optional | Recommended | Mandatory (Critical Data) |
| Local Payment Gateway | Optional | Mandatory | Mandatory |
| 2FA Authentication | Recommended | Mandatory | Mandatory |
| Right to Erasure | 30 days | 45 days | 30 days |
| Audit Log Retention | 6 years | 5 years | 7 years |

---

## 3. Payment System Architecture

### 3.1 System Design Overview

#### 3.1.1 High-Level Architecture

```
┌─────────────┐     ┌──────────────┐     ┌─────────────┐
│   Client    │────▶│   API        │────▶│  Payment    │
│ Application │     │   Gateway    │     │  Service    │
└─────────────┘     └──────────────┘     └─────────────┘
                            │                     │
                            ▼                     ▼
                    ┌──────────────┐     ┌─────────────┐
                    │  Auth        │     │  Provider   │
                    │  Service     │     │  (Stripe)   │
                    └──────────────┘     └─────────────┘
                            │                     │
                            ▼                     ▼
                    ┌──────────────┐     ┌─────────────┐
                    │  Database    │     │  Webhook    │
                    │  Cluster     │     │  Handler    │
                    └──────────────┘     └─────────────┘
```

### 3.2 Payment API Design

#### 3.2.1 RESTful API Endpoints

**Base URL Structure:**
```
https://api.{domain}/v1/payments
```

**Endpoint Specifications:**

##### POST /payments/create-subscription

**Description:** Initiates a new subscription with payment method.

**Request Headers:**
```http
Authorization: Bearer {jwt_token}
Content-Type: application/json
X-Idempotency-Key: {unique_request_id}
X-API-Version: 2024-01
```

**Request Payload:**
```json
{
  "plan_id": "pro_monthly_2024",
  "payment_method_id": "pm_1234567890abcdef",
  "customer_details": {
    "email": "user@example.com",
    "name": "John Doe",
    "country": "GB",
    "tax_id": "GB123456789"
  },
  "billing_cycle": "monthly",
  "currency": "GBP",
  "promotional_code": "SUMMER2024",
  "metadata": {
    "source": "web_app",
    "campaign_id": "q4_2024"
  }
}
```

**Response (201 Created):**
```json
{
  "subscription_id": "sub_9876543210fedcba",
  "status": "active",
  "current_period_start": "2024-10-25T00:00:00Z",
  "current_period_end": "2024-11-25T00:00:00Z",
  "amount": 9900,
  "currency": "GBP",
  "payment_status": "succeeded",
  "invoice_id": "inv_abc123def456",
  "client_secret": "seti_1234_secret_5678",
  "next_payment_date": "2024-11-25T00:00:00Z"
}
```

**Error Response (400 Bad Request):**
```json
{
  "error": {
    "code": "INVALID_PAYMENT_METHOD",
    "message": "The payment method provided is invalid or expired",
    "param": "payment_method_id",
    "type": "validation_error",
    "request_id": "req_abc123xyz789"
  }
}
```

##### POST /payments/update-subscription

**Description:** Modifies existing subscription (upgrade/downgrade/cancel).

**Request Payload:**
```json
{
  "subscription_id": "sub_9876543210fedcba",
  "action": "upgrade",
  "new_plan_id": "business_monthly_2024",
  "proration_behavior": "create_prorations",
  "effective_date": "immediate"
}
```

##### POST /payments/cancel-subscription

**Description:** Cancels subscription with configurable end-of-period option.

**Request Payload:**
```json
{
  "subscription_id": "sub_9876543210fedcba",
  "cancel_at_period_end": true,
  "cancellation_reason": "switching_service",
  "feedback": "Found a more suitable alternative"
}
```

##### GET /payments/subscription/{subscription_id}

**Description:** Retrieves detailed subscription information.

**Response:**
```json
{
  "subscription_id": "sub_9876543210fedcba",
  "customer_id": "cus_abc123def456",
  "status": "active",
  "plan": {
    "id": "pro_monthly_2024",
    "name": "Professional Monthly",
    "amount": 9900,
    "currency": "GBP",
    "interval": "month"
  },
  "current_period": {
    "start": "2024-10-25T00:00:00Z",
    "end": "2024-11-25T00:00:00Z"
  },
  "payment_history": [
    {
      "invoice_id": "inv_001",
      "amount": 9900,
      "status": "paid",
      "paid_at": "2024-10-25T10:30:00Z"
    }
  ],
  "upcoming_invoice": {
    "amount": 9900,
    "date": "2024-11-25T00:00:00Z"
  }
}
```

#### 3.2.2 API Rate Limiting

**Rate Limit Tiers:**
```
Free Tier:       60 requests/minute,  1,000 requests/hour
Starter Tier:   120 requests/minute,  5,000 requests/hour
Professional:   300 requests/minute, 20,000 requests/hour
Business:       600 requests/minute, 50,000 requests/hour
Enterprise:   Custom limits based on agreement
```

**Rate Limit Headers:**
```http
X-RateLimit-Limit: 300
X-RateLimit-Remaining: 287
X-RateLimit-Reset: 1698235200
Retry-After: 60
```

**Rate Limit Exceeded Response (429):**
```json
{
  "error": {
    "code": "RATE_LIMIT_EXCEEDED",
    "message": "API rate limit exceeded. Please retry after 60 seconds.",
    "retry_after": 60,
    "limit": 300,
    "window": "1 minute"
  }
}
```

### 3.3 Webhook Management

#### 3.3.1 Webhook Event Types

**Subscription Events:**
- `subscription.created`
- `subscription.updated`
- `subscription.deleted`
- `subscription.trial_will_end`
- `subscription.paused`
- `subscription.resumed`

**Payment Events:**
- `payment.succeeded`
- `payment.failed`
- `payment.pending`
- `payment.refunded`
- `payment.dispute.created`
- `payment.dispute.resolved`

**Invoice Events:**
- `invoice.created`
- `invoice.finalized`
- `invoice.paid`
- `invoice.payment_failed`
- `invoice.voided`

#### 3.3.2 Webhook Payload Structure

**Example: `payment.failed` Event**
```json
{
  "id": "evt_1234567890abcdef",
  "type": "payment.failed",
  "created": 1698235200,
  "data": {
    "object": {
      "id": "pi_9876543210fedcba",
      "amount": 9900,
      "currency": "GBP",
      "customer": "cus_abc123def456",
      "subscription": "sub_9876543210fedcba",
      "failure_code": "card_declined",
      "failure_message": "Your card was declined",
      "last_payment_error": {
        "code": "card_declined",
        "decline_code": "insufficient_funds",
        "message": "Insufficient funds"
      }
    }
  },
  "livemode": true,
  "pending_webhooks": 1,
  "request": {
    "id": "req_abc123xyz789",
    "idempotency_key": "idem_key_12345"
  }
}
```

#### 3.3.3 Webhook Security

**Signature Verification:**
```python
import hmac
import hashlib

def verify_webhook_signature(payload, signature, secret):
    """
    Verifies webhook signature using HMAC SHA-256
    """
    expected_signature = hmac.new(
        secret.encode('utf-8'),
        payload.encode('utf-8'),
        hashlib.sha256
    ).hexdigest()
    
    return hmac.compare_digest(expected_signature, signature)
```

**Security Headers Required:**
```http
X-Webhook-Signature: sha256=abc123...
X-Webhook-Timestamp: 1698235200
X-Webhook-Id: evt_1234567890abcdef
```

**Replay Attack Prevention:**
- Timestamp validation (reject if > 5 minutes old)
- Event ID deduplication (store processed events for 24h)
- Signature verification on every request

#### 3.3.4 Webhook Retry Logic

**Retry Strategy:**
```
Attempt 1: Immediate
Attempt 2: 5 minutes
Attempt 3: 15 minutes
Attempt 4: 1 hour
Attempt 5: 6 hours
Attempt 6: 24 hours
```

**Exponential Backoff Formula:**
```
delay = min(base_delay * (2 ^ attempt), max_delay)
where:
  base_delay = 5 minutes
  max_delay = 24 hours
```

**Retry Conditions:**
- HTTP 5xx status codes
- Network timeout (>30 seconds)
- Connection refused
- SSL/TLS errors

**No Retry Conditions:**
- HTTP 2xx status codes (success)
- HTTP 4xx status codes (client errors)
- Invalid webhook endpoint
- Signature verification failure

### 3.4 Payment Failure & Retry Logic

#### 3.4.1 Failure Classification

**Hard Failures (No Retry):**
- Card reported lost or stolen
- Fraudulent card
- Card expired (no auto-update available)
- Invalid CVV (after 3 attempts)
- Payment method explicitly blocked

**Soft Failures (Automatic Retry):**
- Insufficient funds
- Temporary decline by issuer
- Card velocity limits exceeded
- Gateway timeout
- Network issues

**Ambiguous Failures (Smart Retry):**
- Generic decline
- Processor error
- Do not honor
- Authentication required

#### 3.4.2 Smart Retry Algorithm

**Decision Tree:**
```
Payment Failed
    │
    ├─ Hard Failure? ──▶ Notify user immediately
    │                    Request new payment method
    │
    ├─ Soft Failure? ──▶ Apply retry strategy
    │                    │
    │                    ├─ Attempt 1: 12 hours
    │                    ├─ Attempt 2: 24 hours
    │                    ├─ Attempt 3: 48 hours
    │                    └─ Attempt 4: 72 hours
    │
    └─ Ambiguous? ─────▶ Machine learning prediction
                         │
                         ├─ High success probability
                         │  └─ Aggressive retry
                         │
                         └─ Low success probability
                            └─ Request user action
```

#### 3.4.3 Grace Period Management

**Grace Period Configuration:**
- **Tier-Based Grace Periods:**
  - Free: 1 day
  - Starter: 3 days
  - Professional: 5 days
  - Business: 7 days
  - Enterprise: Custom (up to 30 days)

**During Grace Period:**
- Full service access maintained
- Daily retry attempts
- Progressive notification escalation
- Billing dashboard alerts
- Email reminders (Day 1, 3, 5, 7)

**Post-Grace Period:**
- Account status: `SUSPENDED`
- Service access: Read-only mode
- Data retention: 30 days
- Recovery option available
- Final reminder sent

#### 3.4.4 Dunning Management

**Communication Strategy:**

**Day 0 (Payment Fails):**
```
Subject: Payment Issue - Action Required
Priority: High
Channel: Email + In-app notification

"We were unable to process your payment. Please update your 
payment method to continue enjoying uninterrupted service."
```

**Day 3:**
```
Subject: Reminder: Update Your Payment Method
Priority: High
Channel: Email + SMS

"Your subscription is at risk. Update your payment method 
within 4 days to avoid service interruption."
```

**Day 6:**
```
Subject: Final Notice - Service Suspension in 24 Hours
Priority: Critical
Channel: Email + SMS + Phone (Enterprise)

"Your account will be suspended tomorrow. Update your payment 
method now to maintain access."
```

**Day 7 (Suspension):**
```
Subject: Account Suspended - Immediate Action Required
Priority: Critical
Channel: Email + SMS

"Your account has been suspended due to payment failure. 
Update your payment method to restore access."
```

---

## 4. Authentication & User Onboarding

### 4.1 Authentication Architecture

#### 4.1.1 Authentication Methods

**Supported Methods:**
1. **Email/Password**: Traditional credential-based auth with bcrypt hashing
2. **OAuth 2.0**: Google, Microsoft, Apple, GitHub
3. **Magic Link**: Passwordless email authentication
4. **Two-Factor Authentication (2FA)**: TOTP-based (Google Authenticator, Authy)
5. **Biometric**: Fingerprint/Face ID (mobile apps)

#### 4.1.2 JWT Token Structure

**Access Token:**
```json
{
  "header": {
    "alg": "RS256",
    "typ": "JWT",
    "kid": "key_id_12345"
  },
  "payload": {
    "sub": "user_abc123def456",
    "email": "user@example.com",
    "role": "professional",
    "subscription_tier": "pro_monthly_2024",
    "permissions": ["read:profile", "write:profile", "manage:subscription"],
    "iat": 1698235200,
    "exp": 1698238800,
    "iss": "https://auth.example.com",
    "aud": "https://api.example.com"
  }
}
```

**Token Lifecycle:**
- Access Token TTL: 1 hour
- Refresh Token TTL: 30 days
- Rotation policy: Refresh token rotates on every use
- Revocation: Immediate via blacklist

#### 4.1.3 Session Management

**Session Storage:**
```javascript
{
  "session_id": "sess_9876543210fedcba",
  "user_id": "user_abc123def456",
  "created_at": "2024-10-25T10:00:00Z",
  "expires_at": "2024-10-25T18:00:00Z",
  "last_activity": "2024-10-25T10:30:00Z",
  "device_info": {
    "user_agent": "Mozilla/5.0...",
    "ip_address": "192.168.1.1",
    "location": "London, UK"
  },
  "security_flags": {
    "is_suspicious": false,
    "risk_score": 0.12,
    "requires_reverification": false
  }
}
```

### 4.2 User Onboarding Flow

#### 4.2.1 Onboarding Screens

**Screen Sequence:**

**1. Welcome Screen**
- Hero image/animation
- Value proposition
- Call-to-action: "Get Started"
- Alternative: "Sign In"

**2. Account Creation**
- Email/password input
- OAuth options
- Terms acceptance checkbox
- Privacy policy link
- CAPTCHA (if risk score > 0.5)

**3. Email Verification**
- Verification code sent
- 6-digit OTP input
- Resend option (1-minute cooldown)
- Email editable

**4. Profile Setup**
- Full name
- Organization (optional)
- Country/region selector
- Phone number (optional, required for 2FA)
- Profile picture upload

**5. Plan Selection**
- Tier comparison matrix
- Feature highlights
- Pricing display (localized)
- Trial period indicator
- Monthly/annual toggle

**6. Payment Information**
- Credit/debit card form
- Alternative payment methods
- Billing address
- Tax information (if applicable)
- Save payment method checkbox
- PCI DSS compliant iframe

**7. Confirmation/Thank You**
- Success confirmation
- Subscription details summary
- Next steps guidance
- Quick start guide link
- Dashboard access button

**8. Initial Loading**
- Account setup progress
- Workspace initialization
- Data sync indicator
- Onboarding checklist preparation
- Redirect to dashboard

#### 4.2.2 Onboarding State Machine

```
START
  │
  ├─▶ WELCOME
  │     │
  │     ├─▶ SIGNUP
  │     │     │
  │     │     ├─▶ EMAIL_VERIFICATION
  │     │     │     │
  │     │     │     ├─▶ PROFILE_SETUP
  │     │     │     │     │
  │     │     │     │     ├─▶ PLAN_SELECTION
  │     │     │     │     │     │
  │     │     │     │     │     ├─▶ PAYMENT_INFO
  │     │     │     │     │     │     │
  │     │     │     │     │     │     ├─▶ PROCESSING
  │     │     │     │     │     │     │     │
  │     │     │     │     │     │     │     ├─▶ SUCCESS
  │     │     │     │     │     │     │     │     │
  │     │     │     │     │     │     │     │     └─▶ DASHBOARD
  │     │     │     │     │     │     │     │
  │     │     │     │     │     │     │     └─▶ ERROR
  │     │     │     │     │     │     │           │
  │     │     │     │     │     │     │           └─▶ RETRY / SUPPORT
  │     │
  │     └─▶ SIGNIN
  │           │
  │           └─▶ DASHBOARD
  │
  └─▶ ERROR_STATE
        │
        └─▶ SUPPORT_CONTACT
```

#### 4.2.3 Thank You Screen Components

**UI Elements:**
```html
<div class="thank-you-container">
  <div class="success-icon">✓</div>
  <h1>Welcome aboard!</h1>
  <p>Your Professional subscription is now active.</p>
  
  <div class="subscription-summary">
    <div class="detail">
      <span>Plan:</span>
      <strong>Professional Monthly</strong>
    </div>
    <div class="detail">
      <span>Next billing date:</span>
      <strong>November 25, 2024</strong>
    </div>
    <div class="detail">
      <span>Amount:</span>
      <strong>£99.00/month</strong>
    </div>
  </div>
  
  <div class="next-steps">
    <h2>Get started with these steps:</h2>
    <ul>
      <li>✓ Complete your profile</li>
      <li>→ Set up your first project</li>
      <li>→ Invite team members</li>
      <li>→ Explore integrations</li>
    </ul>
  </div>
  
  <div class="actions">
    <button class="primary">Go to Dashboard</button>
    <button class="secondary">View Quick Start Guide</button>
  </div>
</div>
```

#### 4.2.4 Loader Screen Design

**Loading States:**

**Initial Setup (0-30%):**
```
"Setting up your account..."
Progress indicator: Spinner
Duration: 2-5 seconds
```

**Workspace Creation (30-60%):**
```
"Creating your workspace..."
Progress indicator: Progress bar
Duration: 3-7 seconds
```

**Data Synchronization (60-90%):**
```
"Syncing your data..."
Progress indicator: Progress bar with percentage
Duration: 5-10 seconds
```

**Finalization (90-100%):**
```
"Almost ready..."
Progress indicator: Animated checkmarks
Duration: 1-2 seconds
```

**Implementation Example:**
```javascript
const OnboardingLoader = () => {
  const [progress, setProgress] = useState(0);
  const [message, setMessage] = useState('');
  
  const stages = [
    { threshold: 30, message: 'Setting up your account...' },
    { threshold: 60, message: 'Creating your workspace...' },
    { threshold: 90, message: 'Syncing your data...' },
    { threshold: 100, message: 'Almost ready...' }
  ];
  
  useEffect(() => {
    const interval = setInterval(() => {
      setProgress(prev => {
        const next = Math.min(prev + Math.random() * 10, 100);
        const stage = stages.find(s => next <= s.threshold);
        setMessage(stage?.message || 'Finalizing...');
        return next;
      });
    }, 500);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="loader-container">
      <div className="loader-animation">
        <Spinner />
      </div>
      <div className="progress-bar">
        <div className="progress-fill" style={{width: `${progress}%`}} />
      </div>
      <p className="loader-message">{message}</p>
      <p className="progress-percentage">{Math.round(progress)}%</p>
    </div>
  );
};
```

### 4.3 User Journey Mapping

#### 4.3.1 Primary User Journey

**New User Acquisition:**
```
Marketing Landing Page
        │
        ├─▶ Value Discovery
        │     │
        │     └─▶ CTA Click
        │
        ├─▶ Onboarding Flow
        │     │
        │     ├─▶ Account Creation (avg: 45 seconds)
        │     ├─▶ Email Verification (avg: 2 minutes)
        │     ├─▶ Profile Setup (avg: 1.5 minutes)
        │     ├─▶ Plan Selection (avg: 3 minutes)
        │     └─▶ Payment (avg: 2 minutes)
        │
        ├─▶ First Session
        │     │
        │     ├─▶ Dashboard Overview
        │     ├─▶ Interactive Tutorial
        │     ├─▶ First Action Completion
        │     └─▶ Success Moment
        │
        └─▶ Activation Point
              │
              └─▶ Regular User
```

**Conversion Funnel Metrics:**
- Landing page → Signup start: 15-20%
- Signup start → Email verified: 60-70%
- Email verified → Profile completed: 80-85%
- Profile completed → Plan selected: 70-75%
- Plan selected → Payment completed: 85-90%
- Overall conversion: ~6-8%

#### 4.3.2 Alternative Journeys

**Trial-to-Paid Conversion:**
```
Free Trial Start
        │
        ├─▶ Day 1-3: Initial engagement
        │     │
        │     └─▶ Feature discovery emails
        │
        ├─▶ Day 4-7: Value realization
        │     │
        │     └─▶ Use case tutorials
        │
        ├─▶ Day 8-14: Limit approaching
        │     │
        │     └─▶ Upgrade prompts
        │
        └─▶ Day 15: Trial ending
              │
              ├─▶ Convert to paid (target: 25-30%)
              │
              └─▶ Downgrade to free (70-75%)
```

**Plan Upgrade Journey:**
```
Feature Limit Reached
        │
        ├─▶ In-app Upgrade Prompt
        │     │
        │     ├─▶ Immediate upgrade (impulse)
        │     │
        │     └─▶ Dismiss / Remind later
        │
        ├─▶ Email Campaign
        │     │
        │     ├─▶ Day 1: Feature comparison
        │     ├─▶ Day 3: Case studies
        │     └─▶ Day 7: Limited-time offer
        │
        └─▶ Conversion
              │
              └─▶ Seamless plan transition
```

---

## 5. Backend Reliability & Resilience

### 5.1 API Rate Limiting

#### 5.1.1 Rate Limiting Strategies

**Token Bucket Algorithm:**
```python
class TokenBucket:
    def __init__(self, capacity, refill_rate):
        self.capacity = capacity
        self.tokens = capacity
        self.refill_rate = refill_rate
        self.last_refill = time.time()
    
    def consume(self, tokens=1):
        self._refill()
        if self.tokens >= tokens:
            self.tokens -= tokens
            return True
        return False
    
    def _refill(self):
        now = time.time()
        elapsed = now - self.last_refill
        refill_amount = elapsed * self.refill_rate
        self.tokens = min(self.capacity, self.tokens + refill_amount)
        self.last_refill = now
```

**Sliding Window Counter:**
```python
class SlidingWindowRateLimiter:
    def __init__(self, redis_client, window_size, max_requests):
        self